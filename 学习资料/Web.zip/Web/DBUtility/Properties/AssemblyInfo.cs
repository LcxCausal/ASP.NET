﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Maticsoft.DBUtility")]
[assembly: AssemblyDescription("Data Access Application Model By Maticsoft")]
[assembly: AssemblyConfiguration("Maticsoft")]
[assembly: AssemblyCompany("Maticsoft")]
[assembly: AssemblyProduct("Maticsoft.DBUtility")]
[assembly: AssemblyCopyright("Copyright (C) Maticsoft 2004-2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("3.5.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
