﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Maticsoft.BLL;
using Maticsoft.Model;

namespace Maticsoft.Web.Admin
{
    public partial class Default : System.Web.UI.Page
    {
        private BLL.users _bllUsers = new BLL.users();
        private Model.users _modelUsers = new Model.users();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string userName = TxtUserName.Text.Trim();
                string pwd = TxtPwd.Text.Trim();

                if (!_bllUsers.Exists(userName))
                {
                    Response.Write("<script language = javascript> alert('用户不存在！') </script>");
                    return;
                }
                else
                {
                    if(!_bllUsers.Exists(userName,pwd))
                    {
                        Response.Write("<script language = javascript> alert('密码错误！') </script>");
                        return;
                    }
                    else
                    {
                        Session["userinfo"] = userName;
                        Response.Redirect("FirstPage.aspx");
                    }
                }
            }
            catch(Exception err)
            {
                Response.Write("<script language = javascript > alert('" + err.Message + "') </script>");
            }
        }

        protected void BtnRegisterd_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registerd.aspx");
            return;
        }
    }
}