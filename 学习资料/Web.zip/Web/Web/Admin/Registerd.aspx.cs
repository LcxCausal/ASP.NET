﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Maticsoft.BLL;
using Maticsoft.Model;

namespace Maticsoft.Web.Admin
{
    public partial class Registerd : System.Web.UI.Page
    {
        private BLL.users _bllUsers = new BLL.users();
        private Model.users _modelUsers = new Model.users();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnRegisterd_Click(object sender, EventArgs e)
        {
            try
            {
                string reUserName = TxtRegUserName.Text.Trim();
                string rePwd = TxtRegPwd.Text.Trim();
                string reRePwd = TxtReregPwd.Text.Trim();

                if (_bllUsers.Exists(reUserName))
                {
                    Response.Write("<script language = javascript> alert('用户已存在！') </script>");
                    return;
                }
                else
                {
                    if(rePwd != reRePwd)
                    {
                        Response.Write("<script language = javascript> alert('两次密码不相同！') </script>");
                    }
                    else
                    {
                        _modelUsers.userName = reUserName;
                        _modelUsers.pwd = rePwd;
                        if(!_bllUsers.Add(_modelUsers))
                        {
                            Response.Write("<script language = javascript> alert('注册失败！') </script>");
                            return;
                        }
                        else
                        {
                            Response.Write("<script language = javascript> alert('注册成功！') </script>");
                            return;
                        }
                    }
                }
            }
            catch(Exception err)
            {
                Response.Write("<script language = javascript> alter('" + err.Message + "') </script>");
                return;
            }
        }

        protected void BtnReturn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}