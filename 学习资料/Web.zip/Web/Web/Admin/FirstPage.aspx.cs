﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Maticsoft.BLL;
using Maticsoft.Model;

namespace Maticsoft.Web.Admin
{
    public partial class FirstPage : System.Web.UI.Page
    {
        private BLL.users _bllUsers = new BLL.users();
        private Model.users _modelUsers = new Model.users();

        TreeNode root;
        TreeNode node1;
        TreeNode node2;
        TreeNode node3;
        TreeNode node4;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["userinfo"] == null)
                {
                    Response.Redirect("Default.aspx");
                }
                LabUserName.Text = Session["userinfo"].ToString();

                root = new TreeNode("信息管理");
                node1 = new TreeNode("添加文章");
                node2 = new TreeNode("管理文章");
                node3 = new TreeNode("添加图片");
                node4 = new TreeNode("文件管理");

                TvMenu.Nodes.Add(root);
                root.ChildNodes.Add(node1);
                root.ChildNodes.Add(node2);
                root.ChildNodes.Add(node3);
                root.ChildNodes.Add(node4);

                root = new TreeNode("站点管理");
                node1 = new TreeNode("管理密码");
                node2 = new TreeNode("退出登录");
                node3 = new TreeNode("数据管理");
                TvMenu.Nodes.Add(root);
                root.ChildNodes.Add(node1);
                root.ChildNodes.Add(node2);
                root.ChildNodes.Add(node3);

                root = new TreeNode("版权信息");
                node1 = new TreeNode("官方网站");

                TvMenu.Nodes.Add(root);
                root.ChildNodes.Add(node1);

            }
        }

        protected void TvMenu_SelectedNodeChanged(object sender, EventArgs e)
        {
            if (TvMenu.Nodes[0].Selected)
            {
                if(TvMenu.Nodes[0].ChildNodes[0].Selected)
                {
                    Response.Redirect("FirstPage.aspx");
                }
                else if(TvMenu.Nodes[0].ChildNodes[1].Selected)
                {
                    Response.Redirect("FirstPage.aspx");
                }
                else if(TvMenu.Nodes[0].ChildNodes[2].Selected)
                {
                    Response.Redirect("FirstPage.aspx");
                }
                else if(TvMenu.Nodes[0].ChildNodes[3].Selected)
                {
                    Response.Redirect("FirstPage.aspx");
                }
                else
                {
                    Response.Redirect("FirstPage.aspx");
                }
            }
            else if(TvMenu.Nodes[1].Selected)
            {
                if (TvMenu.Nodes[1].ChildNodes[0].Selected)
                {
                    Response.Redirect("FirstPage.aspx");
                }
                else if (TvMenu.Nodes[1].ChildNodes[1].Selected)
                {
                    Response.Redirect("FirstPage.aspx");
                }
                else if (TvMenu.Nodes[1].ChildNodes[2].Selected)
                {
                    Response.Redirect("FirstPage.aspx");
                }
                else
                {
                    Response.Redirect("FirstPage.aspx");
                }
            }
            else if(TvMenu.Nodes[2].Selected)
            {
                if (TvMenu.Nodes[1].ChildNodes[0].Selected)
                {
                    Response.Redirect("FirstPage.aspx");
                }
                else
                {
                    Response.Redirect("FirstPage.aspx");
                }
            }
            else
            {
                Response.Redirect("FirstPage.aspx");
            }
        }
    }
}